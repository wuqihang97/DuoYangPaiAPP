package cn.tedu.wqhtest.net;

public enum HttpMethod {
	GET,POST
}
