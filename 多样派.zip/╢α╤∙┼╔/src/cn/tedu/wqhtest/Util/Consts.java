package cn.tedu.wqhtest.Util;

public interface Consts {
}
