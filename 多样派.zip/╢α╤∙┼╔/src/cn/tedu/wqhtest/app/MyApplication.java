package cn.tedu.wqhtest.app;

import android.app.Application;

public class MyApplication extends Application{
	
}
